﻿namespace WindowsFormsApplication1
{
    partial class Regisztracio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.lbl_nev = new System.Windows.Forms.Label();
            this.lbl_felhasznalonev = new System.Windows.Forms.Label();
            this.lbl_jelszo = new System.Windows.Forms.Label();
            this.lbl_jelszoujra = new System.Windows.Forms.Label();
            this.btn_felvitel = new System.Windows.Forms.Button();
            this.btn_vissza = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(119, 46);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(189, 20);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(119, 72);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(189, 20);
            this.textBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(119, 98);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(189, 20);
            this.textBox3.TabIndex = 2;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(119, 124);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(189, 20);
            this.textBox4.TabIndex = 3;
            // 
            // lbl_nev
            // 
            this.lbl_nev.AutoSize = true;
            this.lbl_nev.Location = new System.Drawing.Point(32, 49);
            this.lbl_nev.Name = "lbl_nev";
            this.lbl_nev.Size = new System.Drawing.Size(27, 13);
            this.lbl_nev.TabIndex = 4;
            this.lbl_nev.Text = "Név";
            // 
            // lbl_felhasznalonev
            // 
            this.lbl_felhasznalonev.AutoSize = true;
            this.lbl_felhasznalonev.Location = new System.Drawing.Point(32, 75);
            this.lbl_felhasznalonev.Name = "lbl_felhasznalonev";
            this.lbl_felhasznalonev.Size = new System.Drawing.Size(81, 13);
            this.lbl_felhasznalonev.TabIndex = 5;
            this.lbl_felhasznalonev.Text = "Felhasználónév";
            // 
            // lbl_jelszo
            // 
            this.lbl_jelszo.AutoSize = true;
            this.lbl_jelszo.Location = new System.Drawing.Point(32, 101);
            this.lbl_jelszo.Name = "lbl_jelszo";
            this.lbl_jelszo.Size = new System.Drawing.Size(36, 13);
            this.lbl_jelszo.TabIndex = 6;
            this.lbl_jelszo.Text = "Jelszó";
            // 
            // lbl_jelszoujra
            // 
            this.lbl_jelszoujra.AutoSize = true;
            this.lbl_jelszoujra.Location = new System.Drawing.Point(32, 127);
            this.lbl_jelszoujra.Name = "lbl_jelszoujra";
            this.lbl_jelszoujra.Size = new System.Drawing.Size(56, 13);
            this.lbl_jelszoujra.TabIndex = 7;
            this.lbl_jelszoujra.Text = "Jelszó újra";
            // 
            // btn_felvitel
            // 
            this.btn_felvitel.Location = new System.Drawing.Point(138, 169);
            this.btn_felvitel.Name = "btn_felvitel";
            this.btn_felvitel.Size = new System.Drawing.Size(154, 39);
            this.btn_felvitel.TabIndex = 8;
            this.btn_felvitel.Text = "Felvitel";
            this.btn_felvitel.UseVisualStyleBackColor = true;
            // 
            // btn_vissza
            // 
            this.btn_vissza.Location = new System.Drawing.Point(138, 214);
            this.btn_vissza.Name = "btn_vissza";
            this.btn_vissza.Size = new System.Drawing.Size(154, 39);
            this.btn_vissza.TabIndex = 9;
            this.btn_vissza.Text = "Vissza";
            this.btn_vissza.UseVisualStyleBackColor = true;
            this.btn_vissza.Click += new System.EventHandler(this.btn_vissza_Click);
            // 
            // Regisztracio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 297);
            this.Controls.Add(this.btn_vissza);
            this.Controls.Add(this.btn_felvitel);
            this.Controls.Add(this.lbl_jelszoujra);
            this.Controls.Add(this.lbl_jelszo);
            this.Controls.Add(this.lbl_felhasznalonev);
            this.Controls.Add(this.lbl_nev);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "Regisztracio";
            this.Text = "Regisztracio";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label lbl_nev;
        private System.Windows.Forms.Label lbl_felhasznalonev;
        private System.Windows.Forms.Label lbl_jelszo;
        private System.Windows.Forms.Label lbl_jelszoujra;
        private System.Windows.Forms.Button btn_felvitel;
        private System.Windows.Forms.Button btn_vissza;
    }
}